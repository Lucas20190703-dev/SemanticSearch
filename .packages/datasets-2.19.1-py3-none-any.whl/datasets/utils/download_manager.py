# deprecated, please use datasets.download.download_manager
